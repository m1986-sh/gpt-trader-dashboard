# GPT Trader Dashboard
This is the initial structure for the GPT Trader Dashboard project.